<?php

$lista = array("peliculas"=>array(
        array("img"=>"img/1.png","nombre"=>"Pelicula de Comedia"),
        array("img"=>"img/2.png","nombre"=>"Pelicula de Terror"),
        array("img"=>"img/3.png","nombre"=>"Pelicula de Comedia"),
        array("img"=>"img/4.png","nombre"=>"Pelicula de Romantica"),
        array("img"=>"img/5.png","nombre"=>"Pelicula de Comedia"),
        array("img"=>"img/6.png","nombre"=>"Pelicula de Accion"),
        array("img"=>"img/7.png","nombre"=>"Pelicula de Terror"),
        array("img"=>"img/8.jpg","nombre"=>"Pelicula de Terror")
    )
);

echo json_encode($lista);
?>