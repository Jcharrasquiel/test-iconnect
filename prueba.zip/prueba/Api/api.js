[
    {
        "img": "img/1.png",
        "nombre": "Pelicula de Miedo"
    },
    {
        "img": "img/2.png",
        "nombre": "Pelicula de terror"
    }
]